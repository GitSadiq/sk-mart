import RouterWrapper from "./config/router";
import "./App.scss"

function App() {
  return (
    <RouterWrapper />
  );
}

export default App;
