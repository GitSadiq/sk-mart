import "../scss/components/footer.scss";

export default function Footer() {
  return (
    <div className="footer-body">
      <p>SK MART Designed & Developed by SK Technologies</p>
    </div>
  );
}
