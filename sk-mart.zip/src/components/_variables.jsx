const layout = {
    labelCol: {
        span: 6,
    },
    wrapperCol: {
        span: 16,
    }
}

export {  layout }